<?php

//key_id 
//key_secret

$keyid = "rzp_test_hTeGxlMOJkRmYF";
$keysecret = "2NUB83q45WBMoAWQBOfSnfwB";
?>